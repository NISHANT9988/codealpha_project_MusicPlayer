const audio = document.getElementById('audio');
const playBtn = document.getElementById('play');
const prevBtn = document.getElementById('prev');
const nextBtn = document.getElementById('next');
const title = document.getElementById('title');
const artist = document.getElementById('artist');
const progressContainer = document.getElementById('progress-container');
const progress = document.getElementById('progress');
const currentTimeEl = document.getElementById('current-time');
const durationEl = document.getElementById('duration');
const volumeSlider = document.getElementById('volume');
const playlistEl = document.getElementById('playlist');

let songIndex = 0;
let isPlaying = false;

const songs = [
  { title: "Song One", artist: "Artist A", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-1.mp3" },
  { title: "Song Two", artist: "Artist B", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-2.mp3" },
  { title: "Song Three", artist: "Artist C", src: "https://www.soundhelix.com/examples/mp3/SoundHelix-Song-3.mp3" },
   { title: "Song forth", artist: "Artist D", src: "https://music.apple.com/au/album/maar-hoi-samiyana-me-single/1835082967" }
];

// Load Song
function loadSong(song) {
  title.textContent = song.title;
  artist.textContent = song.artist;
  audio.src = song.src;

  // Update playlist UI
  document.querySelectorAll('#playlist li').forEach((li, index) => {
    li.classList.toggle('active', index === songIndex);
  });
}

// Play Song
function playSong() {
  isPlaying = true;
  audio.play();
  playBtn.textContent = "⏸️";
}

// Pause Song
function pauseSong() {
  isPlaying = false;
  audio.pause();
  playBtn.textContent = "▶️";
}

// Next Song
function nextSong() {
  songIndex++;
  if (songIndex > songs.length - 1) songIndex = 0;
  loadSong(songs[songIndex]);
  playSong();
}

// Prev Song
function prevSong() {
  songIndex--;
  if (songIndex < 0) songIndex = songs.length - 1;
  loadSong(songs[songIndex]);
  playSong();
}

// Update Progress
function updateProgress(e) {
  const { duration, currentTime } = e.srcElement;
  const progressPercent = (currentTime / duration) * 100;
  progress.style.width = `${progressPercent}%`;

  let minutes = Math.floor(currentTime / 60);
  let seconds = Math.floor(currentTime % 60);
  if (seconds < 10) seconds = "0" + seconds;
  currentTimeEl.textContent = `${minutes}:${seconds}`;

  if (duration) {
    let durMinutes = Math.floor(duration / 60);
    let durSeconds = Math.floor(duration % 60);
    if (durSeconds < 10) durSeconds = "0" + durSeconds;
    durationEl.textContent = `${durMinutes}:${durSeconds}`;
  }
}

// Set Progress
function setProgress(e) {
  const width = this.clientWidth;
  const clickX = e.offsetX;
  const duration = audio.duration;
  audio.currentTime = (clickX / width) * duration;
}

// Volume Control
volumeSlider.addEventListener('input', () => {
  audio.volume = volumeSlider.value;
});

// Event Listeners
playBtn.addEventListener('click', () => (isPlaying ? pauseSong() : playSong()));
prevBtn.addEventListener('click', prevSong);
nextBtn.addEventListener('click', nextSong);

audio.addEventListener('timeupdate', updateProgress);
progressContainer.addEventListener('click', setProgress);
audio.addEventListener('ended', nextSong); // autoplay next

// Build Playlist
songs.forEach((song, index) => {
  const li = document.createElement('li');
  li.textContent = `${song.title} - ${song.artist}`;
  li.addEventListener('click', () => {
    songIndex = index;
    loadSong(songs[songIndex]);
    playSong();
  });
  playlistEl.appendChild(li);
});

// Init
loadSong(songs[songIndex]);
